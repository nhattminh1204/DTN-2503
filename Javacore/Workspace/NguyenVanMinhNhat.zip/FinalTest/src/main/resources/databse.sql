-- 1. Tạo database
CREATE DATABASE IF NOT EXISTS user_management;
USE user_management;

-- 2. Tạo bảng user
CREATE TABLE IF NOT EXISTS user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(200) NOT NULL,
    exp_in_year INT,
    pro_skill VARCHAR(100),
    project_id INT,
    role ENUM('admin', 'manager', 'employee') NOT NULL
);

-- 3. Insert dữ liệu mẫu
INSERT INTO user (full_name, email, password, exp_in_year, project_id, role)
VALUES
('Nguyen Thi A', 'nguyen.a@email.com', 'password123', 5, 101, 'manager'),
('Tran Thi C', 'tran.c@email.com', 'password123', 8, 102, 'manager'),
('Nguyen Thi B', 'nguyen.b@email.com', 'password123', NULL, 101, 'employee'),
('Le Thi D', 'le.d@email.com', 'password123', NULL, 102, 'employee'),
('Admin User', 'admin@email.com', 'admin123', NULL, NULL, 'admin'),
('Nguyễn Văn Minh Nhật', 'nhattminh1204@gmail.com', '123456', NULL, NULL, 'manager'),
('Hồ Nguyễn Huyền Trang', 'htrang0801@gmail.com', '123456', NULL, NULL, 'manager'),
('Trần Nguyễn Khánh Vinh', 'tnkvinh@gmail.com', '123456', NULL, NULL, 'manager');

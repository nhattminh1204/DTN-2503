package repository;

import entity.Employee;
import entity.Manager;
import entity.User;

import java.util.List;

public interface IUserRepository {
    List<Employee> getEmployeesByProjectId(int projectId);
    List<Manager> getAllManagers();
    Manager loginManager(String email, String password);
}

package repository;

import entity.Employee;
import entity.Manager;
import entity.User;
import utils.JDBCUtils;
import utils.ScannerUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserRepository implements IUserRepository{

    @Override
    public List<Employee> getEmployeesByProjectId(int projectId) {
        List<Employee> employees = new ArrayList<>();
        String sql = "SELECT id, full_name, email, password, project_id, pro_skill FROM user WHERE role = 'employee' AND project_id = ?";

        try (Connection cn = JDBCUtils.getConnection()) {
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setInt(1, projectId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Employee e = new Employee(
                        rs.getInt("id"),
                        rs.getString("full_name"),
                        rs.getString("email"),
                        rs.getString("password"),
                        rs.getInt("project_id"),
                        rs.getString("pro_skill")
                );
                employees.add(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employees;
    }

    @Override
    public List<Manager> getAllManagers() {
        List<Manager> managers = new ArrayList<>();
        String sql = "SELECT id, full_name, email, password, exp_in_year, project_id FROM user WHERE role = 'manager'";

        try (Connection cn = JDBCUtils.getConnection()) {
            PreparedStatement ps = cn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Manager m = new Manager(
                        rs.getInt("id"),
                        rs.getString("full_name"),
                        rs.getString("email"),
                        rs.getString("password"),
                        rs.getInt("exp_in_year"),
                        rs.getInt("project_id")
                );

                managers.add(m);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return managers;
    }

    @Override
    public Manager loginManager(String email, String password) {
        String sql = "SELECT * FROM user WHERE role = 'manager' AND email = ? AND password = ?";
        try (Connection cn = JDBCUtils.getConnection()) {
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Manager(
                        rs.getInt("id"),
                        rs.getString("full_name"),
                        rs.getString("email"),
                        rs.getString("password"),
                        rs.getInt("exp_in_year"),
                        rs.getInt("project_id")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

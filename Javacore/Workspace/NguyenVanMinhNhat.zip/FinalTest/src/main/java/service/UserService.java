package service;

import entity.Employee;
import entity.Manager;
import entity.User;
import repository.IUserRepository;
import repository.UserRepository;
import utils.HashUtil;
import utils.JDBCUtils;
import utils.ScannerUtils;
import utils.ValidationUtils;

import java.util.List;

public class UserService implements IUserService{
    private IUserRepository userRepository;

    public UserService() {
        userRepository = new UserRepository();
    }

    public List<Employee> getEmployeesByProjectId(int projectId) {
        return userRepository.getEmployeesByProjectId(projectId);
    }

    public List<Manager> getAllManagers() {
        return userRepository.getAllManagers();
    }

    public Manager loginManager(String email, String password) {
        if (!ScannerUtils.isValidEmail(email)) {
            System.out.println("Email không đúng định dạng (ví dụ: abc@vti.com.vn)");
            return null;
        }
        if (!ScannerUtils.isValidPassword(password)) {
            System.out.println("Password phải từ 6 đến 12 ký tự.");
            return null;
        }

        String hashedPassword = HashUtil.hashPassword(password, "SHA-512");

        return userRepository.loginManager(email, hashedPassword);
    }
}

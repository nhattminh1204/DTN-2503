package entity;

public class Admin {
}

package controller;

import entity.Employee;
import entity.Manager;
import entity.User;
import service.IUserService;
import service.UserService;
import utils.HashUtil;
import utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class UserController {
    private IUserService userService = new UserService();

    public List<Employee> getEmployeesByProjectId(int projectID) {
        return userService.getEmployeesByProjectId(projectID);
    }

    public List<Manager> getAllManagers() {
        return userService.getAllManagers();
    }

    public Manager loginManager(String email, String password) {
        return userService.loginManager(email, password);
    }

    public void convertAllPasswordsToHash() {
        String sqlSelect = "SELECT id, password FROM user";
        String sqlUpdate = "UPDATE user SET password = ? WHERE id = ?";

        try (Connection cn = JDBCUtils.getConnection();
             PreparedStatement psSelect = cn.prepareStatement(sqlSelect);
             PreparedStatement psUpdate = cn.prepareStatement(sqlUpdate);
             ResultSet rs = psSelect.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String oldPassword = rs.getString("password");

                if (oldPassword.length() > 30) continue;

                String hashed = HashUtil.hashPassword(oldPassword, "SHA-512");

                psUpdate.setString(1, hashed);
                psUpdate.setInt(2, id);
                psUpdate.executeUpdate();
            }

            System.out.println("Đã chuyển toàn bộ mật khẩu thành SHA-512.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}

import controller.UserController;
import entity.Employee;
import entity.Manager;
import entity.User;
import utils.JDBCUtils;
import utils.ScannerUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Program {
    private static UserController userController = new UserController();

    public static void main(String[] args) {
        while (true) {
            System.out.println("================================================ MENU ================================================");
            System.out.println("1. Danh sách các Employee theo Project ID.");
            System.out.println("2. Danh sách tất cả các Manager.");
            System.out.println("3. Đăng nhập với tư cách Manager.");
            System.out.println("0. Thoát.");
            System.out.print("Chọn chức năng: ");
            int menu = ScannerUtils.inputMenu(0, 3);

            switch (menu) {
                case 1:
                    cau1();
                    break;
                case 2:
                    cau2();
                    break;
                case 3:
                    cau3();
                    break;
                case 0:
                    System.out.println("Thoát chương trình.");
                    return;
            }
        }
    }

    private static void cau1() {
        System.out.print("Nhập ID Project: ");
        int projectId = ScannerUtils.inputInt();
        List<Employee> employees = userController.getEmployeesByProjectId(projectId);
        if (employees.isEmpty()) {
            System.out.println("Không có nhân viên nào trong dự án này.");
        } else {
            System.out.printf("%-5s %-20s %-30s %-10s %-20s\n",
                    "ID", "Full Name", "Email", "ProjectID", "Pro Skill");
            for (Employee e : employees) {
                System.out.printf("%-5d %-20s %-30s %-10d %-20s\n",
                        e.getId(), e.getFullName(), e.getEmail(), e.getProjectID(), e.getProSkill());
            }
        }
    }

    private static void cau2() {
        List<Manager> managers = userController.getAllManagers();
        if (managers.isEmpty()) {
            System.out.println("Không có manager nào.");
        } else {
            System.out.printf("%-5s %-30s %-30s %-12s %-10s\n",
                    "ID", "Full Name", "Email", "Exp (năm)", "ProjectID");
            for (Manager m : managers) {
                System.out.printf("%-5d %-30s %-30s %-12d %-10d\n",
                        m.getId(), m.getFullName(), m.getEmail(), m.getExpInYear(), m.getProjectId());
            }
        }
    }

    private static void cau3() {
        System.out.print("Nhập email: ");
        String email = ScannerUtils.inputEmail();
        System.out.print("Nhập password: ");
        String password = ScannerUtils.inputPassword();

        Manager manager = userController.loginManager(email, password);
        if (manager != null) {
            System.out.println("Đăng nhập thành công!");
            System.out.println("Xin chào: " + manager.getFullName());
        } else {
            System.out.println("Đăng nhập thất bại. Email hoặc mật khẩu không đúng.");
        }
    }
}

